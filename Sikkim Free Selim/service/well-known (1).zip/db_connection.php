<?php
$host = 'localhost';
$dbname = 'yaks6354_51game';
$username = 'yaks6354_51game';
$password = 'H^AnnjO8^yUE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Could not connect to the database: " . $e->getMessage());
}
?>
